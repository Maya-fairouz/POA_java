/**
 * 
 */
/**
 * @author Maya
 *
 */
module complimentGE {
	requires java.desktop;
}